#!/usr/bin/env bash
docker container exec -it debian-repository bash
